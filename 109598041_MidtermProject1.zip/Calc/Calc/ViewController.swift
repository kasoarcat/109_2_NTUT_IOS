//
//  ViewController.swift
//  Calc
//
//  Created by jakey on 2021/3/8.
//

import UIKit

class ViewController: UIViewController {
    
    var calculator = Calculator()
    
    @IBOutlet weak var b0: UIButton!
    @IBOutlet weak var b1: UIButton!
    @IBOutlet weak var b2: UIButton!
    @IBOutlet weak var b3: UIButton!
    @IBOutlet weak var b4: UIButton!
    @IBOutlet weak var b5: UIButton!
    @IBOutlet weak var b7: UIButton!
    @IBOutlet weak var b6: UIButton!
    @IBOutlet weak var b8: UIButton!
    @IBOutlet weak var b9: UIButton!
    
    @IBOutlet weak var expressionsLabel: UILabel!
    @IBOutlet weak var resultLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func p0(_ sender: Any) {
        expressionsLabel.text = calculator.action(symbol: .zero)
    }
    
    @IBAction func p1(_ sender: Any) {
        expressionsLabel.text = calculator.action(symbol: .one)
    }
    
    @IBAction func p2(_ sender: Any) {
        expressionsLabel.text = calculator.action(symbol: .two)
    }
    
    @IBAction func p3(_ sender: Any) {
        expressionsLabel.text = calculator.action(symbol: .three)
    }
    
    @IBAction func p4(_ sender: Any) {
        expressionsLabel.text = calculator.action(symbol: .four)
    }
    
    @IBAction func p5(_ sender: Any) {
        expressionsLabel.text = calculator.action(symbol: .five)
    }
    
    @IBAction func p6(_ sender: Any) {
        expressionsLabel.text = calculator.action(symbol: .six)
    }
    
    @IBAction func p7(_ sender: Any) {
        expressionsLabel.text = calculator.action(symbol: .seven)
    }
    
    @IBAction func p8(_ sender: Any) {
        expressionsLabel.text = calculator.action(symbol: .eight)
    }
    
    @IBAction func p9(_ sender: Any) {
        expressionsLabel.text = calculator.action(symbol: .nine)
    }
    
    @IBAction func pDot(_ sender: Any) {
        expressionsLabel.text = calculator.action(symbol: .dot)
    }
    
    @IBAction func add(_ sender: Any) {
        expressionsLabel.text = calculator.action(symbol: .add)
    }
    
    @IBAction func sub(_ sender: Any) {
        expressionsLabel.text = calculator.action(symbol: .sub)
    }
    
    @IBAction func mult(_ sender: Any) {
        expressionsLabel.text = calculator.action(symbol: .mul)
    }
    
    @IBAction func div(_ sender: Any) {
        expressionsLabel.text = calculator.action(symbol: .div)
    }
    
    @IBAction func sign(_ sender: Any) {
        expressionsLabel.text = calculator.action(symbol: .sign)
    }
    
    @IBAction func percent(_ sender: Any) {
        expressionsLabel.text = calculator.action(symbol: .percent)
    }
    
    @IBAction func clean(_ sender: Any) {
        (expressionsLabel.text, resultLabel.text) = calculator.clean()
    }
    
    @IBAction func equal(_ sender: Any) {
        resultLabel.text = calculator.execute()
    }
}

