//
//  CalcData.swift
//  Calc
//
//  Created by jakey on 2021/4/24.
//

import Foundation

enum Symbol: Character {
    case add = "+"
    case sub = "-"
    case mul = "x"
    case div = "÷"
    
    case one   = "1"
    case two   = "2"
    case three = "3"
    case four  = "4"
    case five  = "5"
    case six   = "6"
    case seven = "7"
    case eight = "8"
    case nine  = "9"
    case zero  = "0"
    
    case dot = "."
    case percent = "%"
    case sign = "±"
    case lbracket = "("
    case rbracket = ")"
}
