//
//  Calculator.swift
//  Calc
//
//  Created by jakey on 2021/4/24.
//

import Foundation

class Calculator {
    var expressions: String! = ""
    
    
    init() {}
    
    
    // 清除計算機，回傳expressionsLabel與resultLabel
    func clean() -> (String, String) {
        expressions = "0"
        return ("0", "0")
    }
    
    
    func isOperator(symbol: Symbol) -> Bool {
        switch symbol {
        case .add, .sub, .mul, .div:
            return true
        default:
            return false
        }
    }
    
    
    func addSymbol(symbol: Symbol) {
        // 負符號±需要加在符號內
        if expressions.count > 0 && expressions.last! == Symbol.rbracket.rawValue {
            expressions.removeLast()
            expressions.append(symbol.rawValue)
            expressions.append(Symbol.rbracket.rawValue)
        } else {
            expressions.append(symbol.rawValue)
        }
    }
    
    
    func fetchContent(symbol: Symbol, closure: (String) -> Void) {
        // 抓取內容
        if expressions.count > 0 {
            var doIt = true
            var content = ""
            for i in expressions.reversed() {
                let subSymbol = Symbol(rawValue: i)!
                
                // 如果是運算子就跳過
                if isOperator(symbol: subSymbol) {
                    break
                }
                
                // 如果是目前操作的符號就跳過，除了sign±
                if subSymbol != .sign && subSymbol == symbol {
                    doIt = false
                    break
                }
                
                // 加入字元
                content.append(i)
            }
            
            if doIt {
                closure(String(content.reversed()))
            }
        } else {
            closure("")
        }
    }
    
    
    // 當採取動作時，如按下一個按鈕，會帶入一個字元
    func action(symbol: Symbol) -> String {
        switch symbol {
        case .add, .sub, .mul, .div:
            // 如果初始按下運算符，就填入0
            if expressions == "" {
                expressions = "0"
            }
            // 如果前一個是運算符，就移除
            else if isOperator(symbol: Symbol(rawValue: expressions.last!)!) {
                expressions.removeLast()
                expressions.append(symbol.rawValue)
            } else {
                expressions.append(symbol.rawValue)
            }
            
        case .zero, .one, .two, .three, .four, .five, .six, .seven, .eight, .nine:
            if expressions == "0" {
                expressions.removeLast()
            }
            addSymbol(symbol: symbol)
            
        case .sign:
            if expressions == "" || expressions == "0" {
                break
            }
            if isOperator(symbol: Symbol(rawValue: expressions.last!)!) {
                break
            }
            fetchContent(symbol: symbol) { (content) in
//                print("content:", content)
                var val: String
                // 排除括號(或)
                if content[content.startIndex] == Symbol.sign.rawValue {
                    let start = content.index(content.startIndex, offsetBy: 2)
                    let end = content.index(content.endIndex, offsetBy: -1)
                    let range = start..<end
                    val = String(content[range])
                } else {
                    val = "\(symbol.rawValue)(\(content))"
                }
//                print("val:", val)
                let prefix = expressions.prefix(expressions.count - content.count)
//                print("prefix", prefix)
                expressions = prefix + val
            }
            
        case .dot:
            if expressions == "" {
                expressions = "0"
            }
            
            fetchContent(symbol: symbol) { (content) in
                addSymbol(symbol: symbol)
            }
            
        case .percent:
            if expressions == "" || expressions == "0" {
                break
            }
            if isOperator(symbol: Symbol(rawValue: expressions.last!)!) {
                break
            }
            fetchContent(symbol: symbol) { (content) in
                var val: String
                // ±括號
                if content[content.startIndex] == Symbol.sign.rawValue {
                    let start = content.index(content.startIndex, offsetBy: 2)
                    let end = content.index(content.endIndex, offsetBy: -1)
                    let range = start..<end
                    val = String(Double(content[range])! / 100)
                    val = "\(Symbol.sign.rawValue)(\(val))"
                } else {
                    val = String(Double(content)! / 100)
                }
                
//                print("percent:", val)
                let prefix = expressions.prefix(expressions.count - content.count)
//                print("prefix", prefix)
                expressions = prefix + val
            }
            
        default:
            print("Error")
        }
        
        return expressions
    }
    
    
    func execute() -> String {
        func calVal() {
            if val != "" {
                values.append(sign ? -Double(val)! : Double(val)!)
                sign = false
                val = ""
            }
        }
        
        // 如果表達式是空的或最後的字元為運算符就不執行
        if expressions.count == 0  || expressions == "" || expressions == "0" || isOperator(symbol: Symbol(rawValue: expressions.last!)!) {
            return "0"
        }

        var op_lists: [Character] = [] // 運算子清單
        var values: [Double] = []
        var val = ""
        var sign = false
        for i in expressions {
            let subSymbol = Symbol(rawValue: i)!
            switch(subSymbol) {
            case .add, .sub, .mul, .div:
                op_lists.append(subSymbol.rawValue)
                calVal()
            case .lbracket, .rbracket:
                break
            case .sign:
                sign = true
            case .zero, .one, .two, .three, .four, .five, .six, .seven, .eight, .nine, .dot:
                val.append(i)
            default:
                print("Error:", i)
            }
        }
        
        calVal()
        for op in op_lists {
            let subSymbol = Symbol(rawValue: op)!
            switch(subSymbol) {
            case .mul, .div:
                calc_operator(&op_lists, &values, subSymbol.rawValue)
            default:
                break
            }
        }
        
        for op in op_lists {
            let subSymbol = Symbol(rawValue: op)!
            switch(subSymbol) {
            case .add, .sub:
                calc_operator(&op_lists, &values, subSymbol.rawValue)
            default:
                break
            }
        }
        
        let formatter = NumberFormatter()
        formatter.minimumFractionDigits = 0
        formatter.maximumFractionDigits = 10
        if values[0].isInfinite {
            values[0] = 0
        }
        return formatter.string(from: NSNumber(value: values[0]))!
    }

    
    private func calc_operator(_ op_lists: inout [Character], _ values: inout [Double], _ opt: Character) {
        if let idx = op_lists.firstIndex(of: opt) {
            op_lists.remove(at: idx)
            let a = values.remove(at: idx)
            let b = values.remove(at: idx)
            
            let symbol = Symbol(rawValue: opt)!
            switch symbol {
            case .mul:
                values.insert(a * b, at: idx)
            case .add:
                values.insert(a + b, at: idx)
            case .sub:
                values.insert(a - b, at: idx)
            case .div:
                values.insert(a / b, at: idx)
            default:
                print("Error!")
            }
        }
    }
}
