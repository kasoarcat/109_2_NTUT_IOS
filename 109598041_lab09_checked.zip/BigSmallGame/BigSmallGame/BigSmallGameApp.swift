//
//  BigSmallGameApp.swift
//  BigSmallGame
//
//  Created by SHIH-YING PAN on 2021/5/17.
//

import SwiftUI

@main
struct BigSmallGameApp: App {
    var body: some Scene {
        WindowGroup {
            GameView()
        }
    }
}
