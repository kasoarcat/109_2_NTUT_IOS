//
//  Action.swift
//  BigSmallGame
//
//  Created by jakey on 2021/5/19.
//

import Foundation

struct Action {
    let action: RockPaperScissors
    
    enum RockPaperScissors: String {
        case rock = "石頭"
        case paper = "布"
        case scissors = "剪刀"
    }
}
