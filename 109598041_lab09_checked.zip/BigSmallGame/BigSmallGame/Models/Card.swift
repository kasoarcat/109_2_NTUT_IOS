//
//  Card.swift
//  BigSmallGame
//
//  Created by SHIH-YING PAN on 2021/5/17.
//

import Foundation

struct Card {
    let suit: Suit
    let rank: Rank
    
    enum Suit: String, CaseIterable {
        case spades = "♠"
        case hearts = "♥︎"
        case diamonds = "♦︎"
        case clubs = "♣"
    }
    
    enum Rank: String, CaseIterable  {
        case ace = "A"
        case two = "2"
        case three = "3"
        case four = "4"
        case five = "5"
        case six = "6"
        case seven = "7"
        case eight = "8"
        case nine = "9"
        case ten = "10"
        case jack = "J"
        case queen = "Q"
        case king = "K"
    }
}


