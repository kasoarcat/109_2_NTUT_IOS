//
//  GameResult.swift
//  BigSmallGame
//
//  Created by SHIH-YING PAN on 2021/5/17.
//

import Foundation

enum GameResult {
    case win
    case lose
    case even
}
