//
//  GameView.swift
//  BigSmallGame
//
//  Created by SHIH-YING PAN on 2021/5/17.
//

import SwiftUI

struct GameView: View {
    @StateObject var gameViewModel = GameViewModel()
    let resultList: [GameResult:String] = [.win:"贏", .lose:"輸", .even:"平手"]
    
    var body: some View {
        VStack {
            Text("猜拳遊戲")
            Spacer()
            HStack(spacing: 100.0) {
                VStack {
                    Text("玩家")
                    Text(gameViewModel.playerAction?.rawValue ?? "?")
                    Image(gameViewModel.playerAction?.rawValue ?? "?")
                }
                VStack {
                    Text("電腦")
                    Text(gameViewModel.computerAction?.rawValue ?? "?")
                    Image(gameViewModel.computerAction?.rawValue ?? "?")
                }
            }
            
            if let result = gameViewModel.result {
                Text(resultList[result]!)
            }

            Button(action: {
                gameViewModel.play()
            }, label: {
                Text("Play")
            })
            
        }
        .font(.largeTitle)
        
    }
    
}

struct GameView_Previews: PreviewProvider {
    static var previews: some View {
        GameView()
    }
}
