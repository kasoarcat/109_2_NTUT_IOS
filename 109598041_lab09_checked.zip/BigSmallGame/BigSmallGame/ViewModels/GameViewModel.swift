//
//  GameViewModel.swift
//  BigSmallGame
//
//  Created by SHIH-YING PAN on 2021/5/17.
//

import Foundation

class GameViewModel: ObservableObject {
    @Published var playerAction: Action.RockPaperScissors?
    @Published var computerAction: Action.RockPaperScissors?
    @Published var result: GameResult?
    
    func play() {
//        actions.shuffle()
//
        let arr: [String] = ["石頭", "布", "剪刀"]
//        let arr: [String] = ["rock", "paper", "scissors"]
        let player = arr[Int.random(in: 0...2)]
        let computer = arr[Int.random(in: 0...2)]
//        print(player)
//        print(computer)
        playerAction = Action.RockPaperScissors(rawValue: player)!
        computerAction = Action.RockPaperScissors(rawValue: computer)!
//        print(playerAction)
//        print(computerAction)
        result = checkResult()
    }
    
    func checkResult() ->  GameResult {
        if (playerAction == Action.RockPaperScissors.paper && computerAction == Action.RockPaperScissors.paper) ||
            (playerAction == Action.RockPaperScissors.rock && computerAction == Action.RockPaperScissors.rock) ||
            (playerAction == Action.RockPaperScissors.scissors && computerAction == Action.RockPaperScissors.scissors)
        {
            print("平手")
            return .even
        }
        else if (playerAction == Action.RockPaperScissors.paper && computerAction == Action.RockPaperScissors.rock) ||
                    (playerAction == Action.RockPaperScissors.rock && computerAction == Action.RockPaperScissors.scissors) ||
                    (playerAction == Action.RockPaperScissors.scissors && computerAction == Action.RockPaperScissors.paper)
        {
            print("贏")
            return .win
        }
        else if (playerAction == Action.RockPaperScissors.paper && computerAction == Action.RockPaperScissors.scissors) ||
            (playerAction == Action.RockPaperScissors.rock && computerAction == Action.RockPaperScissors.paper) ||
            (playerAction == Action.RockPaperScissors.scissors && computerAction == Action.RockPaperScissors.rock)
        {
            print("輸")
            return .lose
        }
        
        print("錯誤")
        return .even
    }
    
    
}
