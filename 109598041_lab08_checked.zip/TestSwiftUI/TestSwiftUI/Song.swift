//
//  Song.swift
//  TestSwiftUI
//
//  Created by jakey on 2021/5/4.
//

import Foundation

struct Song: Identifiable {
    let id = UUID()
    let name: String
    let singer: String
    let lyrics: String
}
