//
//  RoleView.swift
//  TestSwiftUI
//
//  Created by jakey on 2021/5/5.
//

import SwiftUI


struct Role: Identifiable {
    let id = UUID()
    let role: String
}

struct RoleView: View {
    let roles: [Role]
    
    var body: some View {
        VStack {
            List(roles) { r in
                Text(r.role)
                    .foregroundColor(.blue)
            }
        }
        .navigationTitle("角色")
    }
}

struct RoleView_Previews: PreviewProvider {
    static var previews: some View {
        RoleView(roles: [Role(role: "小勞勃·道尼"), Role(role: "葛妮絲·派特洛"), Role(role: "唐·奇鐸")])
    }
}
