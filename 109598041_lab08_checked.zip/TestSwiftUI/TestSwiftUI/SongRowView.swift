//
//  SongRowView.swift
//  TestSwiftUI
//
//  Created by jakey on 2021/5/4.
//

import SwiftUI

struct SongRowView: View {
    let song: Song
    
    var body: some View {
        HStack {
            Image(song.name)
                .resizable()
                .scaledToFill()
                .frame(width: 80, height: 80)
                .clipped()
            VStack(alignment: .leading) {
                Text(song.name)
                Text(song.singer)
            }
            Spacer()
        }
    }
}

struct SongRowView_Previews: PreviewProvider {
    static var previews: some View {
        SongRowView(song: Song(name: "cat", singer: "林俊傑", lyrics: "如果愛情是場遠程的渦旋僅管繞著圈子也要走向前不離心太遠 我要面朝最藍的晴天不脫離軌道有你在身邊")).previewLayout(.sizeThatFits)
    }
}
