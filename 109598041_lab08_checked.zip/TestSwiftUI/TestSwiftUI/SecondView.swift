//
//  SecondView.swift
//  TestSwiftUI
//
//  Created by jakey on 2021/5/3.
//

import SwiftUI

struct SecondView: View {
    @Binding var showSecondPage: Bool
    @Binding var number: Int
    
    var body: some View {
        VStack {
            ZStack {
                Color.yellow
                    .edgesIgnoringSafeArea(.all)
                Button(action: {
                    showSecondPage = false
                }, label: {
                    Image(systemName: "\(number).circle.fill")
                        .resizable()
                        .scaledToFit()
                        .foregroundColor(.blue)
                        .padding()
                })
            }
        }
    }
}

struct SecondView_Previews: PreviewProvider {
    static var previews: some View {
        SecondView(showSecondPage: .constant(true), number: .constant(5))
    }
}
