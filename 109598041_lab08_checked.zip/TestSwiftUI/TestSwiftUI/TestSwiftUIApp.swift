//
//  TestSwiftUIApp.swift
//  TestSwiftUI
//
//  Created by jakey on 2021/4/26.
//

import SwiftUI

@main
struct TestSwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
//            IntroView()
        }
    }
}
