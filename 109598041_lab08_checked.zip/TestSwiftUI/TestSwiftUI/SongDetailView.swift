//
//  SongDetailView.swift
//  TestSwiftUI
//
//  Created by jakey on 2021/5/4.
//

import SwiftUI

struct SongDetailView: View {
    let song: Song
    
    var body: some View {
        VStack {
            Image(song.name)
                .resizable()
                .scaledToFill()
                .frame(minWidth: 0, maxWidth: .infinity)
                .frame(height: 300)
                .clipped()
            Text(song.lyrics)
                .padding()
        }
        .navigationTitle(song.name)
    }
}

struct SongDetailView_Previews: PreviewProvider {
    static var previews: some View {
        SongDetailView(song: Song(name: "cat", singer: "林俊傑", lyrics: "如果愛情是場遠程的渦旋僅管繞著圈子也要走向前不離心太遠 我要面朝最藍的晴天不脫離軌道有你在身邊"))
    }
}
