//
//  IntroView.swift
//  TestSwiftUI
//
//  Created by jakey on 2021/5/3.
//

import SwiftUI

struct IntroView: View {
    var body: some View {
        VStack {
            Text("2月7日水中瓶，愛瘋一切為蘋果。桌球快狠不忘準，音樂聲裡讀推理。 非思不可jobs， 為愛尋夢往前飛。iPad不是放大Phone，兩者皆通彼得潘。")
                .foregroundColor(/*@START_MENU_TOKEN@*/.blue/*@END_MENU_TOKEN@*/)
            NavigationLink(
                destination: IntroView(),
                label: {
                    Text("Navigate")
                        .bold()
                        .foregroundColor(/*@START_MENU_TOKEN@*/.blue/*@END_MENU_TOKEN@*/)
                })
        }
        .navigationTitle("spider man")
    }
}

struct IntroView_Previews: PreviewProvider {
    @State private var showSecondPage = false
    
    static var previews: some View {
        IntroView()
    }
}
