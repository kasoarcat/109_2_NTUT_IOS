//
//  SongListView.swift
//  TestSwiftUI
//
//  Created by jakey on 2021/5/4.
//

import SwiftUI

struct SongListView: View {
    let songs = [
        Song(name: "dog", singer: "林俊傑", lyrics: "如果愛情是場遠程的渦旋僅管繞著圈子也要走向前不離心太遠 我要面朝最藍的晴天不脫離軌道有你在身邊"),
        Song(name: "cat", singer: "周杰倫", lyrics: "沒有了聯絡後來的生活 我都是聽別人說 說妳怎麼了 說妳怎麼過 放不下的人是我 人多的時候 就待在角落 就怕別人問起我 你們怎麼了 妳低著頭 護著我連抱怨都沒有")
    ]
    
    var body: some View {
//        List {
//            SongRowView(song: songs[0])
//            SongRowView(song: songs[1])
//        }
        NavigationView {
            List(songs) { song in
//                SongRowView(song: song)
                NavigationLink(
                    destination: SongDetailView(song: song),
                    label: {
                        SongRowView(song: song)
                    }
                )
            }
        }
        .navigationTitle("情歌王")
    }
}

struct SongListView_Previews: PreviewProvider {
    static var previews: some View {
        SongListView()
    }
}
