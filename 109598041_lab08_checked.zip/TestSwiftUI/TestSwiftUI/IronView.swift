//
//  IronView.swift
//  TestSwiftUI
//
//  Created by jakey on 2021/5/5.
//

import SwiftUI

struct Detail: Identifiable {
    let id = UUID()
    let contain: String
}

struct IronView: View {
    let details: [Detail]
    
    var body: some View {
        VStack {
            List(details) { detail in
                Text(detail.contain)
                    .foregroundColor(.blue)
            }
        }
        .navigationTitle("細節")
    }
}

struct IronView_Previews: PreviewProvider {
    static var previews: some View {
        IronView(details: [Detail(contain: "鋼鐵人3》（英語：Iron Man 3，中國大陸譯《鋼鐵俠3》，香港譯《鐵甲奇俠3》）是一部於2013年上映的美國超級英雄電影，改編自漫威漫畫的電影，也是漫威電影宇宙系列中的第七部電影，亦為最後一部由派拉蒙影業參與製作的漫威電影。繼《鋼鐵人2》和《復仇者聯盟》後的延續作品。本片由沙恩·布萊克執導，小勞勃·道尼、葛妮絲·派特洛、唐·奇鐸、蓋·皮爾斯、蕾貝卡·霍爾、史黛芬妮·史佐史塔克、詹姆士·巴奇·戴爾、強·法夫洛以及班·金斯利主演。[5] 該片原先是第一部由中美兩國聯手合拍的超級英雄電影[6]，但之後由於中國對中外合拍片提出新的規範而不得不改為進口買斷片的方式引進中國放映。[7]"), Detail(contain: "本片除了獲得普遍好評外，並取得了商業的成功，全球總收入票房12.14億美元令該片獲得世界電影票房的優異成績，成為2013年在北美第二高的票房電影（僅次於《冰雪奇緣》），它成為第二部漫威電影宇宙系列電影電影總收入超過10億美元，也成為票房第七高的全球最高超級英雄電影票房，該片還獲得奧斯卡最佳視覺效果獎提名，也獲得了第40屆土星獎三個獎項和五個提名。")
        ])
    }
}
