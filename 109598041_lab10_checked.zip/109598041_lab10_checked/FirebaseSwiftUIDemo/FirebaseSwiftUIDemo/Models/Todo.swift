//
//  Todo.swift
//  FirebaseSwiftUIDemo
//
//  Created by jakey on 2021/5/26.
//

import Foundation

import FirebaseFirestoreSwift

struct Todo: Codable, Identifiable {
    @DocumentID var id: String?
    let dueDate: Date
    let name: String
    let isCompile: Bool
}

