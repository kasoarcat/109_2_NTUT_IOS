//
//  TodoListViewModel.swift
//  FirebaseSwiftUIDemo
//
//  Created by jakey on 2021/5/26.
//

import Foundation

import Foundation
import FirebaseFirestore

class TodoListViewModel: ObservableObject {
    @Published var todos: [Todo] = []
    private let store = Firestore.firestore()
    
    init() {
        fetchChanges()
    }
    
    func fetchChanges() {
        store.collection("todo").addSnapshotListener { snapshot, error in
            guard let snapshot = snapshot else { return }
            snapshot.documentChanges.forEach { documentChange in
                guard let todo = try? documentChange.document.data(as: Todo.self) else { return }
                switch documentChange.type {
                case .added: // 新增
                    self.todos.append(todo)
                case .modified: // 修改
                    guard let index = self.todos.firstIndex(where: {
                        $0.id == todo.id
                    }) else { return }
                    self.todos[index] = todo
                case .removed: // 移除
                    guard let index = self.todos.firstIndex(where: {
                        $0.id == todo.id
                    }) else { return }
                    self.todos.remove(at: index)
                }
            }
        }
    }
}
