//
//  TodoListView.swift
//  FirebaseSwiftUIDemo
//
//  Created by jakey on 2021/5/26.
//

import SwiftUI
import FirebaseFirestore

struct TodoListView: View {
    @StateObject var todoListViewModel = TodoListViewModel()
    
    @State var name = ""
    @State var isCompile = false
    @State var dueTime = Date()
    
    var body: some View {
        
        VStack(alignment: .leading) {
            Group {
                HStack {
                    Text("名稱:")
                    TextField("你的名字", text: $name)
                        .border(Color.blue, width: 1)
                        .frame(width: 150, alignment: .center)
                }
                Toggle(isOn: $isCompile, label: {
                    Text("是否完成:")
                })
                DatePicker("到期時間:", selection: $dueTime, in: ...Date())
                Button(action: {
                    do {
                        let db = Firestore.firestore()
                        let todo = Todo(dueDate: dueTime, name: name, isCompile: isCompile)
                        let documentReference = try db.collection("todo").addDocument(from: todo)
                        print(documentReference.documentID)
                    } catch {
                        print(error)
                    }
                }, label: {
                    Text("新增數據")
                        .bold()
                        .frame(width: 300, alignment: .center)
                })
            }
            
            Group {
                Text("-----------------------------------------")
                Text("目前數據")
                    .frame(width: 300, alignment: .center)
                ForEach(todoListViewModel.todos) { todo in
                    Text("名稱: \(todo.name)")
                    Text("到期時間: \(todo.dueDate.description)")
                    Text("是否完成: \(todo.isCompile ? "是" : "否")")
                    Text("-----------------------------------------")
                }
            }
        }
    }
}

struct TodoListView_Previews: PreviewProvider {
    static var previews: some View {
        TodoListView()
    }
}
