//
//  ContentView.swift
//  TestSwiftUI
//
//  Created by jakey on 2021/4/26.
//

import SwiftUI

//struct Song2: Identifiable {
//    var id = UUID()
//    var name: String
//    var singer: String
//}

struct Movie: Identifiable {
    let id = UUID()
    let details: [Detail]
    let roles: [Role]
}

struct ContentView: View {
//    @State private var showSecondPage = false
//    @State var num = 1
//    @State var isRain = Bool.random()
//    @State private var number = 0
//    let lyrics = ["你從不知道", "我因為你而煎熬", "心碎過的每一分每一秒"]
//    var songs = [
//          Song2(name: "小酒窩", singer: "林俊傑"),
//          Song2(name: "你從不知道", singer: "劉增瞳"),
//          Song2(name: "對的時間點", singer: "林俊傑")
//    ]
//
//    func funcABC() {
//        print("follow")
//    }
    
    let movie = Movie(details: [Detail(contain: "鋼鐵人3》（英語：Iron Man 3，中國大陸譯《鋼鐵俠3》，香港譯《鐵甲奇俠3》）是一部於2013年上映的美國超級英雄電影，改編自漫威漫畫的電影，也是漫威電影宇宙系列中的第七部電影，亦為最後一部由派拉蒙影業參與製作的漫威電影。繼《鋼鐵人2》和《復仇者聯盟》後的延續作品。本片由沙恩·布萊克執導，小勞勃·道尼、葛妮絲·派特洛、唐·奇鐸、蓋·皮爾斯、蕾貝卡·霍爾、史黛芬妮·史佐史塔克、詹姆士·巴奇·戴爾、強·法夫洛以及班·金斯利主演。[5] 該片原先是第一部由中美兩國聯手合拍的超級英雄電影[6]，但之後由於中國對中外合拍片提出新的規範而不得不改為進口買斷片的方式引進中國放映。[7]"), Detail(contain: "本片除了獲得普遍好評外，並取得了商業的成功，全球總收入票房12.14億美元令該片獲得世界電影票房的優異成績，成為2013年在北美第二高的票房電影（僅次於《冰雪奇緣》），它成為第二部漫威電影宇宙系列電影電影總收入超過10億美元，也成為票房第七高的全球最高超級英雄電影票房，該片還獲得奧斯卡最佳視覺效果獎提名，也獲得了第40屆土星獎三個獎項和五個提名。")
    ], roles: [Role(role: "小勞勃·道尼"), Role(role: "葛妮絲·派特洛"), Role(role: "唐·奇鐸")])
    
    var body: some View {
//        HStack {
//            VStack {
//                Text("Apple")
//                    .font(.title)
//                    .fontWeight(.bold)
//                    .foregroundColor(Color.red)
//                    .padding()
//                    .background(/*@START_MENU_TOKEN@*//*@PLACEHOLDER=View@*/Color.yellow/*@END_MENU_TOKEN@*/)
//                    .shadow(radius: 20)
//                    .cornerRadius(21.0)
//                    .rotationEffect(.degrees(15))
//                    .rotation3DEffect(Angle(degrees: 30), axis: (x: 10.0, y: 10.0, z: 10.0))
//                    .shadow(radius: 10)
//                Button(action: /*@START_MENU_TOKEN@*//*@PLACEHOLDER=Action@*/{}/*@END_MENU_TOKEN@*/) {
//                    Text("Haha2").foregroundColor(.pink)
//                }
//                Button(action: {}, label: {
//                    HStack {
//                        Image(systemName: "star")
//                        Text("Button")
//                    }
//                })
//                ZStack {
//                    VStack {
//                        Image(systemName: "wifi").resizable().frame(width: 100, height: 100, alignment: .center).scaledToFit()
//                        Text("Placeholder")
//                    }
//                }
//                ZStack {
//                Image("dog")
//                    .resizable()
//                    .scaledToFill()
//                    .frame(width: 100, height: 100, alignment: .center)
//                    .clipped()
//                Image(systemName: "magnifyingglass")
////                    .font(Font.system(size: 100, weight: .heavy))
//                    .resizable()
//                    .frame(width: 100, height: 100, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
//                    .foregroundColor(.red)
//                }
//            }
//        }
    
//        VStack {
//            Button(action: {
//                print("World")
//            }, label: {
//                Text("Button")
//                    .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
//                    .background(/*@START_MENU_TOKEN@*//*@PLACEHOLDER=View@*/Color.yellow/*@END_MENU_TOKEN@*/, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)                    .foregroundColor(.green)
//            })
//            Button("AAA") {
//                print("GGG")
//            }
//            Button("KKK", action: {
//                print("OOO")
//            })
//            Button(action: funcABC) {
//                Text("TTT")
//                    .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
//                    .background(/*@START_MENU_TOKEN@*//*@PLACEHOLDER=View@*/Color.red/*@END_MENU_TOKEN@*/)
//                    .foregroundColor(/*@START_MENU_TOKEN@*/.yellow/*@END_MENU_TOKEN@*/)
//            }
//            Image(systemName: isRain ? "cloud.rain.fill" : "sun.max.fill")
//                .resizable()
//                .frame(width: 100, height: 100, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
//            Button(action: {
//                isRain = Bool.random()
//            }, label: {
//                Text("改變天氣")
//            })
//        }
        
//        VStack {
//            Image(systemName: "die.face.\(num).fill").resizable().frame(width: 50, height: 50, alignment: .center)
//            Button(action: {
//                num = Int.random(in: 1...6)
//            }, label: {
//                Text("玩").font(.title)
//            })
//        }
        
//        VStack {
//            CircleImage(name: "dog")
//            CircleImage(name: "cat")
//            Button(action: {
//                number = Int.random(in: 1...50)
//                showSecondPage = true
//            }, label: {
//                Text("顯示第二頁")
////                    .sheet(isPresented: $showSecondPage, content: {
////                        SecondView(showSecondPage: $showSecondPage, number: $number)
////                    })
//
//                    .fullScreenCover(isPresented: $showSecondPage, content: {
//                        SecondView(showSecondPage: $showSecondPage, number: $number)
//                    })
//            })
//        }

//        NavigationView {
//            VStack {
////                ForEach(0 ..< 5) { item in
////                    Text("對的時間點")
////                }
////                ForEach(0..<lyrics.count) { index in
////                    Text(lyrics[index])
////                }
////                ForEach(lyrics.indices) { index in
////                    Text(lyrics[index])
////                }
////                ForEach(lyrics, id: \.self) { message in
////                    Text(message)
////                }
//                ForEach(songs) { song in
//                    Text("\(song.name) by \(song.singer)")
//                }
//
//                Image(systemName: "clock")
//                    .resizable()
//                    .scaledToFit()
//                    .frame(width: 200, height: 200)
//                NavigationLink(
//                    destination: IntroView(),
//                    label: {
//                        Text("Navigate")
//                    })
////                Link("可不可以你也剛好喜歡我", destination: URL(string: "http://maps.apple.com/?address=臺北市中正區八德路一段1號".addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!)!)
//            }
//            .navigationTitle("首頁")
//            .navigationBarTitleDisplayMode(.inline)
//            .foregroundColor(.blue)
//        }
        
//        List {
//            Text("iPhone 11 Pro Max")
//            Text("iPhone 11 Pro")
//            Text("iPhone 9")
//            Text("iPhone 10")
//            Text("iPhone SE")
//        }
        
//        TabView {
//            SongListView()
//                .tabItem {
//                    Image(systemName: "music.house.fill")
//                    Text("情歌")
//            }
//            IntroView()
//                .tabItem {
//                    Image(systemName: "info.circle.fill")
//                    Text("About")
//            }
//        }
//        .accentColor(.orange)
        
        NavigationView {
            VStack {
                Image("Iron")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 300, height: 300)
                NavigationLink(
                    destination: IronView(details: movie.details),
                    label: {
                        Text("Movie Detail")
                    })
                NavigationLink(
                    destination: RoleView(roles: movie.roles),
                    label: {
                        Text("Movie Actor")
                    })
            }
            .navigationTitle("剛鐵人3")
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

struct CircleImage: View {
    let name: String
    
    var body: some View {
        Image(name)
            .resizable()
            .scaledToFill()
            .frame(width: 200, height: 200)
            .clipShape(Circle())
            .shadow(radius: 20)
    }
}
